# Import the workflow into your n8n instance and configure credentials

1. Open your n8n editor (Render URL).
2. On the left menu: Workflows -> Import -> choose `workflows/global_event_now_n8n_workflow_import.json` from this repo.
3. After import, open the workflow and review the nodes.
4. Set the credentials and keys:
   - NewsAPI: create a credential or set an environment variable NEWSAPI_KEY.
   - YouTube API Key: put your YOUTUBE_API_KEY in the YouTube search node URL or credentials.
   - YouTube OAuth: create an OAuth2 credential in n8n using the Client ID/Client Secret from Google Cloud (OAuth consent must be configured).
   - Optional: OpenAI key for TTS or prompts (OPENAI_API_KEY), ElevenLabs key, Pexels key.
5. Test nodes step-by-step (start with Fetch News node).
6. When verified, enable the workflow and set a schedule (Cron) to run every 3 hours or as desired.
7. Monitor executions and logs from the Executions panel.

If you want, send me screenshots of any errors and I will guide you through fixes.
