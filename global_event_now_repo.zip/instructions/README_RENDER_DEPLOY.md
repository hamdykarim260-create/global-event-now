# Deploy n8n on Render (Free tier)

1. Create an account on https://render.com and sign in.
2. Click **New** → **Web Service**.
3. Choose **Linked Repository** (connect your GitHub and select the official `n8n-io/n8n` repo) OR choose the `Docker` option with the n8n image.
4. For Build Command, use: `npm install`
5. For Start Command, use: `n8n start`
6. Choose **Free** instance.
7. Create the service and wait until it's live. Note the URL Render gives you (e.g. `https://yourproject.onrender.com`).
8. Open the URL and append `/` to reach the n8n editor UI. Log in using your Google account if required (follow Render docs for environment setup).

After Render is running, continue to the n8n setup instructions.
