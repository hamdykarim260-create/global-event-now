FFmpeg editing is performed by the n8n Execute Command node in the workflow. If you self-host, ensure ffmpeg is available on the system.
