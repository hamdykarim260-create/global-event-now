# Global Event Now — Ready-to-Deploy Automation Repo (FREE)
This repository package contains everything you need to run the **Global Event Now** news automation system on a free Render + n8n setup.
It **does not** include any API keys or secrets — you'll add those later inside n8n Credentials.

---
## What is included
- `workflows/global_event_now_n8n_workflow_import.json` — n8n workflow file (import into your n8n instance)
- `instructions/` — step-by-step guides to deploy n8n on Render, import the workflow, and add API keys
- `placeholders/` — simple placeholder scripts to show where editors / processors would run (you don't need to run them manually)
- `LICENSE` — Apache-2.0 (example)

---
## Quick setup summary (short)
1. Create a free account at **Render** (https://render.com).
2. Deploy the official n8n repository (or use Render's template) as a **Web Service** (free tier).
   - Build: `npm install`
   - Start: `n8n start`
3. Open your n8n instance at the Render URL (e.g. `https://yourproject.onrender.com`).
4. In n8n: Workflows → Import → upload `workflows/global_event_now_n8n_workflow_import.json`.
5. Configure the following credentials in n8n (we'll help you place the values):
   - `NEWSAPI_KEY` (NewsAPI.org)
   - `YOUTUBE_API_KEY` and OAuth (Google Cloud OAuth2)
   - (Optional) `OPENAI_API_KEY`, `ELEVENLABS_KEY`, `PEXELS_KEY`, etc.
6. Test a single node (Fetch News) and then enable the workflow's schedule (cron) to run every 3 hours or as you prefer.

---
## Important notes & safety
- This repo intentionally **does not** download copyrighted content that you don't have rights to. The workflow samples use YouTube Creative Commons search and legal news sources only — you must check licensing for any source you use.
- Keep your API keys private — do not commit them to GitHub. Use n8n Credentials or environment variables.
- If you want, I can walk you through configuring each credential step-by-step after you deploy n8n.

---
## Files in this package
- `workflows/global_event_now_n8n_workflow_import.json` — main n8n workflow (importable)
- `instructions/README_RENDER_DEPLOY.md` — full Render deployment steps
- `instructions/IMPORT_AND_CONFIGURE_N8N.md` — how to import workflow and set keys
- `placeholders/` — small example placeholder files (README explains purpose)

---
## Next steps I can do for you (choose after upload)
- Walk you through Render deployment live (step-by-step)
- Walk you through adding each API key inside n8n (YouTube OAuth + API Key, NewsAPI key, OpenAI Key)
- Run a test execution and verify uploads to your YouTube channel
- Troubleshoot any error messages

Reply “GO” and I’ll give you the ZIP download and the exact next action to do on Render. If you want me to proceed automatically I can also paste a ready-to-run `render.yaml` — but you'll still need to push this repo to your GitHub account first.
